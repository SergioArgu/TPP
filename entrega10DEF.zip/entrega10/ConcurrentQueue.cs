﻿using System.Runtime.CompilerServices;

namespace entrega10
{
    public class ConcurrentQueue<T>
    {

        private Lista<T> lista;
        private object locker = new object();//Compartido por todos los hilos

        public ConcurrentQueue()
        {
            lista = new Lista<T>();
        }

        public uint NumberOfElements { 
            
            get {
                
                lock (locker)
                {
                    return lista.NumberOfElements;
                }    
                
            }
        }

        public bool IsEmpty { 
            
            get {

                lock (locker)
                {
                    return lista.NumberOfElements == 0;
                }    
            }
        
        }

        public void Enqueue(T elemento)//Añade un elemento al final de la cola
        {
            lock (locker)
            {
                lista.Add(elemento);
            }
        }

        public T Dequeue()//Elimina el primer elemento de la cola y lo devuelve
        {
            lock (locker)
            {
                if (IsEmpty == false)
                {
                    T result = lista.GetElement(0);
                    lista.Remove(result);
                    return result;
                }
                else
                {
                    return default;
                }
            }
        }

        public T Peek()//Devuelve el primer elemento de la cola
        {
            lock (locker)
            {
                if (IsEmpty == false)
                {
                    T result = lista.GetElement(0);
                    return result;
                }
                else
                {
                    return default;
                }
            }
        }

        static void Main()
        {

        }
    }
}
