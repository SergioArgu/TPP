﻿using System;
namespace entrega10
{
    public class Program
    {
        static void Main()
        {
            
        }

    }
}

