﻿namespace entrega10
{
    internal class Node<T>
    {

        public Node(T valor)
        {
            Valor = valor;
            Siguiente = null;
        }

        public T Valor { get; set; }

        public Node<T>? Siguiente { get; set; }

    }
}
