﻿namespace entrega01
{
    internal class Node
    {
        private Boolean inicial;
        private int valor;
        private Node siguiente;

        public Node(int valor)
        {
            Valor = valor;
            Siguiente = null;
        }

        public int Valor { get; set; }

        public Node Siguiente { get; set; }

    }
}
