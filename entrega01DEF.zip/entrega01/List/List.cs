﻿using System.ComponentModel;
using static System.Runtime.InteropServices.JavaScript.JSType;
using System.Numerics;

namespace entrega01
{
    internal class List
    {

        private int NumberOfElements;
        private Node primerNodo;

        public void Add(int valor)
        {
            if (primerNodo == null)
            {
                primerNodo = new Node(valor);
                primerNodo.Siguiente = null;
            }
            else
            {
                Node nodo = new Node(valor);
                Node nodoActual = primerNodo;
                for (int i = 0; i < NumberOfElements; i++)
                {
                    if (NumberOfElements - 1 == i)
                    {
                        nodoActual.Siguiente = nodo;
                    }
                    nodoActual = nodoActual.Siguiente;
                }
            }
            NumberOfElements++;
        }

        public void Remove(int valor)
        {
            Node nodoActual = primerNodo;
            Node nodoAnterior = nodoActual;
            if (primerNodo.Valor == valor)
            {
                primerNodo = primerNodo.Siguiente;
                NumberOfElements--;
                return;
            }
            for (int i = 0; i < NumberOfElements; i++)
            {
                if (nodoActual.Valor == valor)
                {
                    Console.WriteLine(nodoActual.Valor);
                    nodoAnterior.Siguiente = nodoActual.Siguiente;
                    NumberOfElements--;
                    return;
                }
                nodoAnterior = nodoActual;
                nodoActual = nodoActual.Siguiente;
            }
        }

        public int GetElement(uint number)
        {
           if (number < 0 || number >= NumberOfElements)
                throw new IndexOutOfRangeException("Índice fuera de rango");

           Node nodoActual = primerNodo;
           for (int i = 0; i < number; i++)
           {
                nodoActual = nodoActual.Siguiente;
           }
           return nodoActual.Valor;
        }

        public string mostrarResultado()
        {
            Node nodo = primerNodo;
            string result = "";
            for (int i = 0; i<NumberOfElements; i++)
            {
                result += nodo.Valor + "-";
                nodo = nodo.Siguiente;
            }
            return result;
        }

        static void Main(string[] args)
        {
            List linkedList = new List();
            linkedList.Add(7);
            Console.WriteLine(linkedList.GetElement(0));

            linkedList.Add(3);
            Console.WriteLine(linkedList.GetElement(0));
            Console.WriteLine(linkedList.mostrarResultado());
            
            linkedList.Add(5);
            Console.WriteLine(linkedList.mostrarResultado());
            linkedList.Add(3);
            Console.WriteLine(linkedList.mostrarResultado());
            linkedList.Add(99);
            Console.WriteLine(linkedList.mostrarResultado());
            linkedList.Add(33);
            Console.WriteLine(linkedList.mostrarResultado());
            Console.WriteLine(linkedList.GetElement(0));
            linkedList.Remove(99);
            Console.WriteLine(linkedList.mostrarResultado());

            linkedList.Remove(33);
            Console.WriteLine(linkedList.mostrarResultado());

            linkedList.Remove(3);
            Console.WriteLine(linkedList.mostrarResultado());
            linkedList.Remove(7);
            Console.WriteLine(linkedList.mostrarResultado());

        }
    }
}
