﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Reflection;
using System.Text;

namespace TPP.Laboratory.Functional.Lab08
{
    class Query
    {
        private Model model = new Model();

        private static void Show<T>(IEnumerable<T> collection)
        {
            foreach (var item in collection)
            {
                Console.WriteLine(item);
            }
            Console.WriteLine("Number of items in the collection: {0}.", collection.Count());
        }

        static void Main(string[] args)
        {
            Query query = new Query();
            query.Homework4();
        }

        private void Query1()
        {
            // Modify this query to show the names of the employees older than 50 years
            var employees = model.Employees
                .Where(e => e.Age > 50).Select(e => e.Name);
                
            Console.WriteLine("Employees:");
            Show(employees);
        }

        private void Query2()
        {
            // Show the name and email of the employees who work in Asturias
            var es = model.Employees
                .Where(e => e.Province.ToLower() == "asturias").Select(e => (e.Name, e.Email));//En vez de hacer el string lo haces dupla que evita problemas
            Console.WriteLine("Employees:");
            Show(es);
        }

        // Notice: from now on, check out http://msdn.microsoft.com/en-us/library/9eekhta0.aspx

        private void Query3()
        {
            // Show the names of the departments with more than one employee 18 years old and beyond; 
            // the department should also have any office number starting with "2.1"
            var ds = model.Departments
                //.Where(d => d.Employees
                //                      .Where(e => e.Age >= 18).Count() > 1);   OTRA FORMA
                .Where(d => d.Employees
                                      .Count(e => e.Age >= 18) > 1)
                .Where(d => d.Employees
                                      .Where(e => e.Office.Number.StartsWith("2.1")).Count() > 0)
                .Select(d => d.Name);

            //.Where(d => d.Employees.Any(e => e.Office.Number.StartsWith("2.1")));   OTRA FORMA
            Console.WriteLine("Departments:");
            Show(ds);
        }

        private void Query4a()
        {
            // Show the phone calls of each employee. 
            // Each line should show the name of the employee and the phone call duration in seconds.
            var cs = model.PhoneCalls
                .Where(c => model.Employees.Where(e => e.TelephoneNumber == c.SourceNumber).Count() > 0)
                .Select(c => (model.Employees.First(e => e.TelephoneNumber == c.SourceNumber).Name, c.Seconds));//.Select(c => model.Employees.First(e => e.TelephoneNumber == c.SourceNumber));
            Console.WriteLine("Llamadas:");
            Show(cs);
        }

        private void Query4b()
        {
            // Show the phone calls of each employee. 
            // Each line should show the name of the employee and the phone call duration in seconds.
            var cs = model.Employees
                    .SelectMany(e => model.PhoneCalls.Where(c => c.SourceNumber == e.TelephoneNumber))
                    .Select(c => (model.Employees.First(e => e.TelephoneNumber == c.SourceNumber).Name, c.Seconds));


            Console.WriteLine("Llamadas:");
            Show(cs);
        }

        private void Query4c()
        {
            // Show the phone calls of each employee. 
            // Each line should show the name of the employee and the phone call duration in seconds.


            //Usando join en vez de dos select
            var cs = model.PhoneCalls.Join(model.Employees,
                c => c.SourceNumber,
                e => e.TelephoneNumber,
                (c, e) => (e.Name, c.Seconds));//Mas facil y rapido usar el join.   Si c y e (c, e) son iguales haces la tupla (e.Name, c.Seconds). donde c es SourceNumber y e es TelephoneNumber


            Console.WriteLine("Llamadas:");
            Show(cs);
        }

        private void Query5()
        {
            // Show, grouped by each province, the name of the employees 
            // (both province and employees must be lexicographically ordered)
            var gs = model.Employees
                .OrderBy(e => e.Name)
                .GroupBy(e => e.Province)
                .OrderBy(g => g.Key);//Aqui recibe g que es el tipo raro ese q esplico abajo de IEnumerable

            Console.WriteLine("Employees:");
            Show(gs);//No funciona asi porque el group by devuelve un tipo de Ienumerable donde esta el valor y la key (en este caso es las provincias)
            foreach(var g in gs)
            {
                Console.WriteLine(g.Key);
                Show(g);
            }
        }

        private void Query6a()
        {
            int i = 1;
            var cs = model.PhoneCalls
                //.AsParallel()//Para que vaya más rápido. No se puede usar con el select comentado porquye no es puro
                .OrderByDescending(c => c.Seconds)
                //.Select(c => (i++, c));// c => (i++, c) es una clausure porque tiene una variable libre por lo que al haber una clausure no es código puro por lo que hay condiciones de carrera
                .Zip(Enumerable.Range(0, model.PhoneCalls.Count()), (c, i) => (i+1, c));//Es lo mismo pero sin usar clausures. El zip mezcla información

            Console.WriteLine("Calls:");
            Show(cs);
        }

        private void Query6b()
        {
            // Rank the calls by duration. Show rank position and duration
            int i = 1;
            var cs = model.PhoneCalls
                .AsParallel()//Aqui se puede usar porque este nuevo select si que es puro
                .OrderByDescending(c => c.Seconds)
                .Select((c,i) => (i+1, c));//Si lo haces asi es lo mismo

            Console.WriteLine("Calls:");
            Show(cs);
        }


        /************ Homework **********************************/

        private void Homework1()
        {
            // Show, ordered by age, the names of the employees in the Computer Science department, 
            // who have an office in the Faculty of Science, 
            // and who have done phone calls longer than one minute

            //var e = model.Employees.OrderBy(e => e.Age)
            //    .Join(model.PhoneCalls, e => e.TelephoneNumber, c => c.SourceNumber, (e,c) => (e,c))
            //    .Where(es => es.e.Department.Name.ToLower() == "computer science")
            //    .Where(es => es.e.Office.Building.ToLower() == "faculty of science")
            //    .Where(cs => cs.c.Seconds > 60)
            //    .Select(es => es.e.Name);
            
            var es = model.Employees.Join(model.PhoneCalls, e => e.TelephoneNumber, p => p.SourceNumber, (e, p) => new { e, p })
                    .Where(ep => ep.p.Seconds > 60)
                    .Where(ep => ep.e.Department.Name.ToLower() == "computer science")
                    .Where(ep => ep.e.Office.Building.ToLower() == "faculty of science")
                    .OrderBy(ep => ep.e.Age)
                    .Select(ep => ep.e.Name);
            
            Console.WriteLine("Names: ");
            Show(es);
        }

        private void Homework2()
        {
            // Show the summation, in seconds, of the phone calls done by the employees of the Computer Science department


            //var e = model.Employees.Join(model.PhoneCalls, e => e.TelephoneNumber, c => c.SourceNumber, (e, c) => new { e, c })
            //    .Where(es => es.e.Department.Name.ToLower() == "computer science")
            //    .Aggregate(0, (es, cs) => es + cs.c.Seconds);

            var cs = model.Employees.Join(model.PhoneCalls, e => e.TelephoneNumber, c => c.SourceNumber, (e, c) => new { e, c })
                .Where(ep => ep.e.Department.Name.ToLower() == "computer science")
                .Select(ep => ep.c.Seconds)
                .Aggregate(0, (suma, segundos) => suma + segundos);
            
            Console.WriteLine("Suma: ");
            Console.WriteLine(cs);
        }

        private void Homework3()
        {
            // Show the phone calls done by each department, ordered by department names. 
            // Each line must show “Department = <Name>, Duration = <Seconds>”

            var cs = model.Employees.Join(model.PhoneCalls, e => e.TelephoneNumber, c => c.SourceNumber, (e, c) => new { e.Department.Name, c.Seconds })
                .GroupBy(res => res.Name)
                .OrderBy(g => g.Key)
                .Select(res => (res.Key, res.Sum(res => res.Seconds)));
            Console.WriteLine("Calls: ");
            Show(cs);

        }

        private void Homework4()
        {
            // Show the departments with the youngest employee, 
            // together with the name of the youngest employee and his/her age 
            // (more than one youngest employee may exist)

            var es = model.Employees.GroupBy(e => e.Department.Name)
                .Select(res => (res.Key, res.OrderBy(g => g.Age).FirstOrDefault().Name, res.OrderBy(g => g.Age).FirstOrDefault().Age));
            Console.WriteLine("Department: ");
            Show(es);
        }

        private void Homework5()
        {
            // Show the greatest summation of phone call durations, in seconds, 
            // of the employees in the same department, together with the name of the department 
            // (it can be assumed that there is only one department fulfilling that condition)

            var ds = model.Employees.Join(model.PhoneCalls, e => e.TelephoneNumber, c => c.SourceNumber, (e, c) => new { e.Department.Name, c.Seconds })
                .GroupBy(d => d.Name)
                .Select(res => (res.Key, res.Sum(g => g.Seconds)))
                .OrderByDescending(g => g.Item2)
                .FirstOrDefault();
            Console.WriteLine("Department: ");
            Console.WriteLine(ds);
        }


    }

}
