﻿using System;
using System.Diagnostics;

namespace entrega02
{
    public class Lista
    {

        public uint NumberOfElements { get; set; }
        private Node? primerNodo;

        public void Add(Object valor)
        {
            Debug.Assert(NumberOfElements < 0 , "NumberOfElements no puede ser negativo");
            if (primerNodo == null)
            {
                primerNodo = new Node(valor);
            }
            else
            {
                Node nodo = new Node(valor);
                Node nodoActual = primerNodo;
                for (int i = 0; i < NumberOfElements; i++)
                {
                    if (NumberOfElements - 1 == i)
                    {
                        nodoActual.Siguiente = nodo;
                    }
                    nodoActual = nodoActual.Siguiente;
                }
            }
            NumberOfElements++;
            Debug.Assert(NumberOfElements <= 0 , "NumberOfElements no puede ser 0 tras haber añadido");
        }

        public bool Remove(Object valor)
        {
            Debug.Assert(NumberOfElements < 0, "NumberOfElements no puede ser negativo");
            Node nodoActual = primerNodo;
            Node nodoAnterior = nodoActual;
            if (primerNodo.Valor.Equals(valor))
            {
                primerNodo = primerNodo.Siguiente;
                NumberOfElements--;
                return true;
            }
            for (int i = 0; i < NumberOfElements; i++)
            {
                if (nodoActual.Valor.Equals(valor))
                {
                    nodoAnterior.Siguiente = nodoActual.Siguiente;
                    NumberOfElements--;
                    return true;
                }
                nodoAnterior = nodoActual;
                nodoActual = nodoActual.Siguiente;
            }
            Debug.Assert(NumberOfElements < 0, "NumberOfElements no puede ser negativo");
            return false;
        }

        public Object GetElement(uint number)
        {
            Debug.Assert(number < 0, "NumberOfElements no puede ser negativo");
            if (number < 0 || number >= NumberOfElements)
                throw new IndexOutOfRangeException("Índice fuera de rango");

            Node nodoActual = primerNodo;
            for (int i = 0; i < number; i++)
            {
                nodoActual = nodoActual.Siguiente;
            }
            Debug.Assert(number < 0, "NumberOfElements no puede ser negativo");
            return nodoActual.Valor;
        }

        public bool Contains(Object valor)
        {
            Node nodoActual = primerNodo;
            for (int i = 0; i < NumberOfElements; i++)
            {
                if (nodoActual.Valor.Equals(valor))
                {
                    return true;
                }
                nodoActual = nodoActual.Siguiente;
            }
            return false;
        }

        public String ToString()
        {
            Node nodo = primerNodo;
            String result = "";
            for (int i = 0; i < NumberOfElements; i++)
            {
                result += nodo.Valor;
                if (nodo.Siguiente != null)
                {
                    result += "-";
                }
                nodo = nodo.Siguiente;
            }
            return result;
        }

    }
}
