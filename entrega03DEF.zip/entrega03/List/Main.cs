﻿using System;
namespace entrega02
{
    public class Program
    {
        static void Main()
        {
            Stack stach = new Stack(4);
            stach.Push(1);
            stach.Pop();
        }

    }
}

