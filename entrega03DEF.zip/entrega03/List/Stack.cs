﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace entrega02
{
    public class Stack
    {
        private Lista lista;
        private uint maxNumberOfElements { get; set; }

        public Stack(uint maxNumberOfElements)
        {
            lista = new Lista();
            this.maxNumberOfElements = maxNumberOfElements;
            Debug.Assert(maxNumberOfElements >= 0, "maxNumberOfElements no puede ser negativo");
            Debug.Assert(IsFull, "La pila no puede estar llena");
            Debug.Assert(IsEmpty && IsFull, "No se puede, la pila está vacía");
        }

        public void Push(Object element)
        {
            Debug.Assert(IsEmpty && IsFull, "No se puede, la pila está vacía");
            Debug.Assert(lista.NumberOfElements < 0 || lista.NumberOfElements > maxNumberOfElements, "El número de elemntos de la pila tiene que ser mayor o igual que 0 y menor que el máximo");
            Debug.Assert(IsFull, "No se puede, la pila está llena");
            if (IsFull == false)
            {
                lista.Add(element);
            }
            Debug.Assert(lista.NumberOfElements < 0 || lista.NumberOfElements > maxNumberOfElements, "El número de elemntos de la pila tiene que ser mayor o igual que 0 y menor que el máximo");
            Debug.Assert(IsEmpty && IsFull, "No se puede, la pila está vacía");
        }

        public void Pop()
        {
            Debug.Assert(IsEmpty && IsFull, "No se puede, la pila está vacía");
            Debug.Assert(lista.NumberOfElements < 0 || lista.NumberOfElements > maxNumberOfElements, "El número de elemntos de la pila tiene que ser mayor o igual que 0 y menor que el máximo");
            Debug.Assert(IsEmpty, "No se puede, la pila está vacía");
            if (IsEmpty == false)
            {
                lista.Remove(lista.GetElement(lista.NumberOfElements - 1));
            }
            Debug.Assert(lista.NumberOfElements < 0 || lista.NumberOfElements > maxNumberOfElements, "El número de elemntos de la pila tiene que ser mayor o igual que 0 y menor que el máximo");
            Debug.Assert(IsFull, "La pila no puede estar llena si se hace un pop");
            Debug.Assert(IsEmpty && IsFull, "No se puede, la pila está vacía");
        }

        public bool IsEmpty 
        {
            get { return lista.NumberOfElements == 0; }
        }

        public bool IsFull
        {
            get { return lista.NumberOfElements >= maxNumberOfElements; }
        }
    }
}
