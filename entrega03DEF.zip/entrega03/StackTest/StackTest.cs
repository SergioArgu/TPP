namespace entrega02
{
    [TestClass]
    public class StackTest
    {
        Stack stack;

        [TestMethod]
        public void PushTest()
        {
            stack = new Stack(2);
            Assert.AreEqual(true, stack.IsEmpty);
            stack.Push(1);
            Assert.AreEqual(false, stack.IsFull);
            stack.Push(2);
            Assert.AreEqual(true, stack.IsFull);
            stack.Push(3);
            Assert.AreEqual(true, stack.IsFull);
        }

        [TestMethod]
        public void PopTest()
        {
            stack = new Stack(2);
            Assert.AreEqual(true, stack.IsEmpty);
            stack.Push(1);
            Assert.AreEqual(false, stack.IsFull);
            stack.Push(2);
            Assert.AreEqual(true, stack.IsFull);
            stack.Push(3);
            Assert.AreEqual(true, stack.IsFull);

            stack.Pop();
            Assert.AreEqual(false, stack.IsFull);
            stack.Pop();
            Assert.AreEqual(false, stack.IsFull);
            Assert.AreEqual(true, stack.IsEmpty);

        }

        [TestMethod]
        public void IsFullTest()
        {
            stack = new Stack(2);
            stack.Push(1);
            Assert.AreEqual(false, stack.IsFull);
            stack.Push(2);
            Assert.AreEqual(true, stack.IsFull);
        }

        [TestMethod]
        public void IsEmptyTest()
        {
            stack = new Stack(2);
            Assert.AreEqual(true, stack.IsEmpty);
            stack.Push(1);
            stack.Push(2);
            stack.Push(3);
            Assert.AreEqual(false, stack.IsEmpty);
        }
    }
}