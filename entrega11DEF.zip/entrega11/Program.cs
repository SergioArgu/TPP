﻿using System.Diagnostics;

namespace entrega11
{
    internal class Program
    {

        public static Dictionary<string, int> CuentaPalabrasSecuencial(string archivo) {
            var cuentaPalabras = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);//(StringComparer.OrdinalIgnoreCase) para no tener en cuenta mayusculas y misnusculas
            var file = File.ReadAllLines(archivo);

            foreach (var line in file)
            {
                var words = line.Split(new[] { ' ', '\t', '.', ',', ';', ':', '!', '?', '"', '(', ')', '[', ']', '-', '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries);//StringSplitOptions.RemoveEmptyEntries elimina cadenas vacías

                foreach (var word in words)
                {
                    if (cuentaPalabras.ContainsKey(word))
                        cuentaPalabras[word]++;
                    else
                        cuentaPalabras[word] = 1;
                }
            }
            return cuentaPalabras;
        }

        public static Dictionary<string, int> CuentaPalabrasConcurrente(string archivo) {
            var cuentaPalabras = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);//(StringComparer.OrdinalIgnoreCase) para no tener en cuenta mayusculas y misnusculas
            var file = File.ReadAllLines(archivo);
            object monitor = new object();

            Parallel.ForEach(file, (line) =>
            {
                var words = line.Split(new[] { ' ', '\t', '.', ',', ';', ':', '!', '?', '"', '(', ')', '[', ']', '-', '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries);//StringSplitOptions.RemoveEmptyEntries elimina cadenas vacías

                foreach (var word in words) {
                    lock (monitor) {

                        if (cuentaPalabras.ContainsKey(word)) {
                            cuentaPalabras[word]++;
                        } else {
                            cuentaPalabras[word] = 1;
                        }
                    }
                }

            });
            return cuentaPalabras;
        }

        static void Main(string[] args)
        {
            Stopwatch chrono = new Stopwatch();
            chrono.Start();
            var resultSecuencial = CuentaPalabrasSecuencial("clarin.txt");
            chrono.Stop();
            Console.WriteLine("Elapsed time Secuencial: {0:N} milliseconds.", chrono.ElapsedMilliseconds);

            chrono.Restart();
            var resultConcurrente = CuentaPalabrasSecuencial("clarin.txt");
            chrono.Stop();
            Console.WriteLine("Elapsed time Concurrente: {0:N} milliseconds.", chrono.ElapsedMilliseconds);

            //El beneficio de rendimiento no es demasiado alto puesto que hay que hay que utilizar un lock para evitar condiciones de carrera
            //lo que empeora el rendimiento.

            //Para mejorarlo se podría sustituir la parte del código del lock y lo que protege por metodos específicos que 
            //cumplen esa función directamente.
        }
    }
}
