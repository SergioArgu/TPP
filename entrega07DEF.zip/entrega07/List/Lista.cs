﻿using System;
using System.Collections;
using System.Diagnostics;
using System.Collections.Generic;

namespace entrega02
{
    public class Lista<T> : IEnumerable<T>
    {

        public uint NumberOfElements { get; set; }
        private Node<T>? primerNodo;

        public void Add(T valor)
        {
            Invariantes();
            if (primerNodo == null)
            {
                primerNodo = new Node<T>(valor);
            }
            else
            {
                Node<T> nodo = new Node<T>(valor);
                Node<T> nodoActual = primerNodo;
                for (int i = 0; i < NumberOfElements; i++)
                {
                    if (NumberOfElements - 1 == i)
                    {
                        nodoActual.Siguiente = nodo;
                    }
                    nodoActual = nodoActual.Siguiente;
                }
            }
            NumberOfElements++;
            Invariantes();
            Debug.Assert(NumberOfElements > 0 , "NumberOfElements no puede ser 0 tras haber añadido");
        }

        public bool Remove(T valor)
        {
            Invariantes();
            Node<T> nodoActual = primerNodo;
            Node<T> nodoAnterior = nodoActual;
            if (primerNodo.Valor.Equals(valor))
            {
                primerNodo = primerNodo.Siguiente;
                NumberOfElements--;
                return true;
            }
            for (int i = 0; i < NumberOfElements; i++)
            {
                if (nodoActual.Valor.Equals(valor))
                {
                    nodoAnterior.Siguiente = nodoActual.Siguiente;
                    NumberOfElements--;
                    return true;
                }
                nodoAnterior = nodoActual;
                nodoActual = nodoActual.Siguiente;
            }
            Invariantes();
            return false;
        }

        public T GetElement(uint number)
        {
            Invariantes();
            Debug.Assert(number >= 0 || number < NumberOfElements, "Índice fuera de rango");
            if (number < 0 || number >= NumberOfElements)
                throw new IndexOutOfRangeException("Índice fuera de rango");

            Node<T> nodoActual = primerNodo;
            for (int i = 0; i < number; i++)
            {
                nodoActual = nodoActual.Siguiente;
            }
            Invariantes();
            return nodoActual.Valor;
        }

        public bool Contains(T valor)
        {
            Invariantes();
            Node<T> nodoActual = primerNodo;
            for (int i = 0; i < NumberOfElements; i++)
            {
                if (nodoActual.Valor.Equals(valor))
                {
                    return true;
                }
                nodoActual = nodoActual.Siguiente;
            }
            Invariantes();
            return false;
        }

        public String ToString()
        {
            Invariantes();
            Node<T> nodo = primerNodo;
            String result = "";
            for (int i = 0; i < NumberOfElements; i++)
            {
                result += nodo.Valor;
                if (nodo.Siguiente != null)
                {
                    result += "-";
                }
                nodo = nodo.Siguiente;
            }
            Invariantes();
            return result;
        }

        public void Invariantes()
        {
            Debug.Assert(NumberOfElements >= 0, "NumberOfElements no puede ser negativo");//Primero la condición que tiene que cumplirse y luego lo que pasa si no se cumple
        }

        public IEnumerator<T> GetEnumerator()
        {
            return new ListaEnumerator<T>(this);//Paso como parámetro mi lista
        }

        IEnumerator IEnumerable.GetEnumerator()
        {
            return GetEnumerator();
        }
    }

    internal class ListaEnumerator<T> : IEnumerator<T>
    {
        //Todos los metodos son utilizados internamente para que funcione el foreach aunque no los utilice yo en mi codigo por eso hay que implementarlos
        private Lista<T> lista;
        private int indice = -1;//-1 para no saltarse el primero

        public ListaEnumerator(Lista<T> lista)
        {
            this.lista = lista;
        }

        public T Current
        {
            get
            {
                if (indice < 0 || indice >= lista.NumberOfElements)
                    throw new Exception();
                return lista.GetElement((uint)indice);
            }
        }

        object IEnumerator.Current { get { return Current; } }

        void IDisposable.Dispose()
        {
            
        }

        bool IEnumerator.MoveNext()
        {
            if (indice < lista.NumberOfElements - 1)
            {
                indice++;
                return true;
            }
            return false;
        }

        void IEnumerator.Reset()
        {
            indice = -1;
        }
    }
}
