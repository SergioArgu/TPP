﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace entrega02
{
    public class Stack<T>
    {
        private Lista<T> lista;
        private uint maxNumberOfElements { get; set; }

        public Stack(uint maxNumberOfElements)
        {
            Debug.Assert(maxNumberOfElements > 0, "maxNumberOfElements no puede ser menor o igual a 0");
            lista = new Lista<T>();
            this.maxNumberOfElements = maxNumberOfElements;
            Debug.Assert(IsEmpty, "La pila no puede estar llena");
            Invariantes();
        }

        public void Push(T element)
        {
            Invariantes();
            Debug.Assert(IsFull == false, "La pila no puede estar llena");
            if (IsFull == false)
            {
                lista.Add(element);
            }
            Debug.Assert(IsEmpty == false, "La pila no puede estar vacía si se hace un push");
            Invariantes();
        }

        public void Pop()
        {
            Invariantes();
            Debug.Assert(IsEmpty == false, "No se puede, la pila está vacía");
            if (IsEmpty == false)
            {
                lista.Remove(lista.GetElement(lista.NumberOfElements - 1));
            }
            Debug.Assert(IsFull == false, "La pila no puede estar llena si se hace un pop");
            Invariantes();
        }

        public bool IsEmpty 
        {
            get {
                Invariantes(); 
                return lista.NumberOfElements == 0; 
                }
        }

        public bool IsFull
        {

            get {
                Invariantes();
                return lista.NumberOfElements >= maxNumberOfElements;
                }
        }

        private void Invariantes()
        {
            Debug.Assert((IsEmpty && IsFull) == false, "La pila no puede estar vacía y llena a la vez");
            Debug.Assert(lista.NumberOfElements > 0 && lista.NumberOfElements <= maxNumberOfElements, "El número de elemntos de la pila tiene que ser mayor que 0 y menor que el máximo");
        }
    }
}
