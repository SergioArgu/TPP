﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace entrega02
{
    public static class MetodosVarios
    {
        public static T Find<T>(this IEnumerable<T> xs, Func<T, bool> f)
        {
            foreach (var x in xs)
            {
                if (f(x))
                {
                    return x;
                }
            }
            throw new Exception();
        }

        public static IEnumerable<T> Filter<T>(this IEnumerable<T> xs, Func<T, bool> f)
        {
            foreach (var x in xs)
            {
                if (f(x))
                {
                    yield return x;
                }
            }
        }

        public static R Reduce<D,R>(this IEnumerable<D> xs, Func<D,R,R> f, R semilla = default)
        {
            R result = semilla;
            foreach (var x in xs)
            {
                result = f(x, result);
            }
            return result;
        }

        public static IEnumerable<T> Invert<T>(this IEnumerable<T> xs)
        {
            foreach (var x in xs.Reverse())
            {
                yield return x;
            }
        }

        public static IEnumerable<R> Map<D, R>(this IEnumerable<D> xs, Func<D, R> f)
        {
            foreach (var x in xs)
            {
                yield return f(x);
            }
        }

        public static IEnumerable<T> ForEach<T>(this IEnumerable<T> xs, Action<T> f)//Action__> recibe D y no devuelve nada
        {
            foreach (var x in xs)
            {
                f(x);//Ejecuto la action
                yield return x;//Devuelvo el valor
            }

        }

    }
}
