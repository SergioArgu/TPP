using entrega05;
using System.Linq;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace testLinq
{
    [TestClass]
    public class UnitTest1
    {

        [TestMethod]
        public void Find()
        {
            var xs = Factory.CreatePeople();
            var angles = Factory.CreateAngles();

            var result = xs.FirstOrDefault(p => p.FirstName == "Pepe");
            Assert.AreEqual("Pepe", result.FirstName);

            var result2 = xs.FirstOrDefault(p => p.FirstName == "Juan");
            Assert.AreEqual("Juan", result2.FirstName);

            var nif = xs.FirstOrDefault(p => p.IDNumber.EndsWith("F"));
            Assert.AreEqual("Juan", nif.FirstName);

            var angulosRectos = angles.FirstOrDefault(p => p.Degrees == 90);
            Assert.AreEqual(90, angulosRectos.Degrees);

            var angulosCuadrante = angles.FirstOrDefault(p => p.Quadrant == 3);
            Assert.AreEqual(3, angulosCuadrante.Quadrant);
        }

        [TestMethod]
        public void Filter()
        {
            var xs = Factory.CreatePeople();
            var angles = Factory.CreateAngles();

            var result = xs.Where(p => p.FirstName == "Pepe");
            foreach (var x in result)
            {
                Assert.AreEqual("Pepe", x.FirstName);
            }

            var result2 = xs.Where(p => p.FirstName == "Juan");
            foreach (var x in result2)
            {
                Assert.AreEqual("Juan", x.FirstName);
            }

            var nif = xs.Where(p => p.IDNumber.EndsWith("F"));
            foreach (var x in nif)
            {
                Assert.IsTrue(x.IDNumber.EndsWith("F"));
            }

            var angulosRectos = angles.Where(p => p.Degrees == 90);
            foreach (var x in angulosRectos)
            {
                Assert.AreEqual(90, x.Degrees);
            }

            var angulosCuadrante = angles.Where(p => p.Quadrant == 3);
            foreach (var x in angulosCuadrante)
            {
                Assert.AreEqual(3, x.Quadrant);
            }
        }

        [TestMethod]
        public void Reduce()
        {
            var angles = Factory.CreateAngles();

            var result = angles.Aggregate(0.0,(p,t) => p + t.Degrees);
            Assert.AreEqual(64980, result);

            var result2 = angles.Aggregate(0.0,(p, t) => Math.Max(Math.Sin(t.Radians),p));
            Assert.AreEqual(1, result2);

            var xs = Factory.CreatePeople();
            var result3 = xs.GroupBy(p => p.FirstName).Select(group => new { Nombre = group.Key, Count = group.Count() });
            var resultado = new List<dynamic>
                                            {
                                                new { Nombre = "Mar�a", Count = 2 },
                                                new { Nombre = "Juan", Count = 2 },
                                                new { Nombre = "Pepe", Count = 1 },
                                                new { Nombre = "Luis", Count = 1 },
                                                new { Nombre = "Carlos", Count = 1 },
                                                new { Nombre = "Miguel", Count = 1 },
                                                new { Nombre = "Cristina", Count = 1 }
                                            };
            int i = 0;
            foreach (var x in result3)
            {
                Assert.AreEqual(resultado[i].Nombre, x.Nombre);
                Assert.AreEqual(resultado[i].Count, x.Count);
                i++;
            }

        }

        [TestMethod]
        public void Map()
        {
            var xs = Factory.CreatePeople();

            var res = xs.Select(p => $"{p.Surname},{p.FirstName}");
            int i = 0;
            foreach (var x in res)
            {
                Assert.AreEqual(((Person)xs.GetValue(i)).Surname + "," + ((Person)xs.GetValue(i)).FirstName, x);
                i++;
            }

            var angles = Factory.CreateAngles();
            var res2 = angles.Select(p => $"{p.Quadrant}");
            i = 0;
            foreach (var x in res2)
            {
                Assert.AreEqual(((Angle)angles.GetValue(i)).Quadrant+"", x);
                i++;
            }
        }
    }
}