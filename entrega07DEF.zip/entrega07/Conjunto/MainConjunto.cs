﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace entrega02
{
    public class MainConjunto
    {
        static void Main(string[] args)
        {
            Conjunto<int> conjunto1 = new Conjunto<int>();
            conjunto1 = conjunto1 + 1;  // Añadir el elemento 1
            conjunto1 = conjunto1 + 2;  // Añadir el elemento 2
            conjunto1 = conjunto1 + 1;  // Añadir el elemento 1
            conjunto1 = conjunto1 + 3;  // Añadir el elemento 3
            Console.WriteLine("Conjunto 1: " + conjunto1.ToString());
        }

    }
    
}
