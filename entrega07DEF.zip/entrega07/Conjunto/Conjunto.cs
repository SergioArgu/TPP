﻿using System.Linq.Expressions;
using System.Xml.Linq;

namespace entrega02
{
    internal class Conjunto<T>
    {
        private Lista<T> elementos;
        private uint NumberOfElements { get { return elementos.NumberOfElements; }}

        public Conjunto()
        {
            elementos = new Lista<T>();
        }

        public static Conjunto<T> operator +(Conjunto<T> c, T valor)//A la izquierda lo que quieres que sea el primer operador y a la derecha lo que quieres que sea el segundo
        {
            if (!c.elementos.Contains(valor))
            {
                c.elementos.Add(valor);
            }
            return c;
        }

        public static Conjunto<T> operator -(Conjunto<T> c, T valor)
        {
            if (c.elementos.Contains(valor))
            {
                c.elementos.Remove(valor);
            }
            return c;
        }

        public T this[uint indice]
        {
            get
            {
                if (indice < 0 || indice >= elementos.NumberOfElements)
                    throw new IndexOutOfRangeException("Índice fuera de rango.");
                return elementos.GetElement(indice);
            }
        }

        public static Conjunto<T> operator |(Conjunto<T> a, Conjunto<T> b)
        {
            Conjunto<T> aux = a;
            for (uint i = 0; i<b.elementos.NumberOfElements; i++)
            {
                if (!aux.elementos.Contains(b.elementos.GetElement(i)))
                {
                    aux.elementos.Add(b.elementos.GetElement(i));
                }
            }
            return aux;
        }

        public static Conjunto<T> operator &(Conjunto<T> a, Conjunto<T> b)
        {
            Conjunto<T> aux = new Conjunto<T>();
            for (uint i = 0; i < b.elementos.NumberOfElements; i++)
            {
                if (a.elementos.Contains(b.elementos.GetElement(i)))
                {
                    aux.elementos.Add(b.elementos.GetElement(i));
                }
            }
            return aux;
        }

        public static Conjunto<T> operator -(Conjunto<T> a, Conjunto<T> b)
        {
            Conjunto<T> aux = a;
            for (uint i = 0; i < b.elementos.NumberOfElements; i++)
            {
                if (aux.elementos.Contains(b.elementos.GetElement(i)))
                {
                    aux.elementos.Remove(b.elementos.GetElement(i));
                }
            }
            return aux;
        }

        public static bool operator ^(Conjunto<T> c, T valor)
        {
            if (c.elementos.Contains(valor))
            {
                return true;
            }
            return false;
        }

        public String ToString()
        {
            return elementos.ToString();
        }

        
    }
}
