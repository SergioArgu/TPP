namespace System.Collections.Generic
{
    [TestClass]
    public class PruebasIList
    {
        IList<int> lista;

        [TestMethod]
        public void AddTest()//A�adir elementos
        {
            lista = new List<int>();
            lista.Add(1);
            lista.Add(2);
            Assert.AreEqual(2, lista.Count);
            Assert.AreEqual(false, lista.Contains(3));
            Assert.AreEqual(true, lista.Contains(2));
        }

        [TestMethod]
        public void CountTest()//Conocer el n�mero de elementos
        {
            lista = new List<int>();
            lista.Add(1);
            lista.Add(2);
            Assert.AreEqual(2, lista.Count);
        }

        [TestMethod]
        public void GetElementTest()//Obtener y reescribir el elemento de la posici�n n-�sima
        {
            lista = new List<int>();
            lista.Add(1);
            lista.Add(2);
            int n = 7;
            Assert.AreEqual(lista[0], 1);
            lista[0] = n;
            Assert.AreEqual(lista[0], n);
        }

        [TestMethod]
        public void ContainsTest()//Saber si un elemento est� o no en el vector
        {
            lista = new List<int>();
            lista.Add(1);
            lista.Add(2);
            Assert.AreEqual(false, lista.Contains(3));
            Assert.AreEqual(true, lista.Contains(2));
        }

        [TestMethod]
        public void PrimerIndiceTest()//Conocer el primer �ndice de un elemento dado, en el caso que exista
        {
            lista = new List<int>();
            lista.Add(1);
            lista.Add(2);
            int indice = lista.IndexOf(2);
            Assert.AreEqual(1, indice);
        }

        [TestMethod]
        public void RemoveTest()//Borrar la primera aparici�n de un elemento dado
        {
            lista = new List<int>();
            lista.Add(1);
            lista.Add(2);
            lista.Add(3);
            lista.Add(2);
            lista.Remove(2);
            Assert.AreEqual(lista[1], 3);
        }

        [TestMethod]
        public void ForeachTest()//Iteraci�n mediante un foreach
        {
            lista = new List<int>();
            lista.Add(1);
            lista.Add(2);
            lista.Add(3);
            lista.Add(2);
            foreach (int aux in lista)
            {
                Assert.AreEqual(true, lista.Contains(aux));
            }
        }
    }
}