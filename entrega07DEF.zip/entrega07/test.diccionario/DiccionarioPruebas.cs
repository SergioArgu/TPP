namespace System.Collections.Generic
{
    [TestClass]
    public class DiccionarioPruebas
    {
        IDictionary<int, String> dict;

        [TestMethod]
        public void AddTest()//A�adir elementos con clave y valor dados
        {
            dict = new Dictionary<int, String>();
            dict.Add(3, "Messi");
            dict.Add(6, "Ronaldo");
            Assert.AreEqual(2, dict.Count);
            Assert.AreEqual(true, dict.ContainsKey(3));
        }

        public void CountTest()//Conocer el n�mero de pares de la colecci�n
        {
            dict = new Dictionary<int, String>();
            dict.Add(3, "Messi");
            dict.Add(6, "Ronaldo");
            Assert.AreEqual(2, dict.Count);
        }

        public void ReescribirTest()//Obtener y reescribir el valor para una clave dada
        {
            dict = new Dictionary<int, String>();
            dict.Add(3, "Messi");
            dict.Add(6, "Ronaldo");
            int n = 6;
            dict[6] = "Neymar";
            Assert.AreEqual(2, dict.Count);
            Assert.AreEqual(true, dict.ContainsKey(6));
            Assert.AreEqual("Neymar", dict[6]);
        }

        public void ContainsKeyTest()//Saber si una clave est� o no en la colecci�n
        {
            dict = new Dictionary<int, String>();
            dict.Add(3, "Messi");
            dict.Add(6, "Ronaldo");
            Assert.AreEqual(2, dict.Count);
            Assert.AreEqual(true, dict.ContainsKey(3));
            Assert.AreEqual(false, dict.ContainsKey(7));
        }

        public void RemoveTest()//Borrar, cuando exista, el elemento de la colecci�n pasando su clave
        {
            dict = new Dictionary<int, String>();
            dict.Add(3, "Messi");
            dict.Add(6, "Ronaldo");
            dict.Remove(3);
            Assert.AreEqual(false, dict.ContainsKey(3));
        }

        public void ForeachTest()//Iteraci�n mediante un foreach
        {
            dict = new Dictionary<int, String>();
            foreach (KeyValuePair<int, String> aux in dict)
            {
                Assert.AreEqual(true, dict.Contains(aux));
            }
        }
    }
}