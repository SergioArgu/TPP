﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace TPP.Laboratory.Functional.Lab06 {

    static class Fibonacci {

        static internal IEnumerable<int> InfiniteFibonacci() {
            int first = 1, second = 1;
            while (true) {
                yield return first;//Cuando tiene un valor lo pasa y no se ejecuta lo de abajo hasta hacer lo del bucle donde lo llamas (enProgram)
                int addition = first + second;//Empieza aqui despues de devolver el valor en el foreach de program
                first = second;
                second = addition;
            }
        }


        static internal IEnumerable<int> LazyFibonacci(int from, int to)//Evaluación perezosa
        {
            return InfiniteFibonacci().Skip(from-1).Take(to-from+1);//Skip se salta los valores hasta el que quieres
        }//Ahora se puede usar sin tener que hacer un break al llamarlo


        static internal IEnumerable<int> EagerFibonacci(int from, int to)//Hacerlo con bucles. No vale usar el Infinitive mi Lazy
        {
            int valorMenosUno = 1;
            int valorMenosDos = 0;
            int valorActual = 0;
            List<int> list = new List<int>();
            for (int i = 2; i < from; i++)
            {
                valorActual = valorMenosDos + valorMenosUno;
                valorMenosDos = valorMenosUno;
                valorMenosUno = valorActual;
            }
            for (int i = from; i <= to; i++)
            {
                if (i == 0)
                {
                    valorActual = 0;
                    list.Add(valorActual);
                }
                else if (i == 1 || i == 2)
                {
                    valorActual = 1;
                    list.Add(valorActual);
                }
                else
                {
                    valorActual = valorMenosDos + valorMenosUno;
                    list.Add(valorActual);
                }
                valorMenosDos = valorMenosUno;
                valorMenosUno = valorActual;
            }
            return list;
        }

    }

}
