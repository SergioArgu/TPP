﻿using System;
using System.Diagnostics;

namespace TPP.Laboratory.Functional.Lab06 {

    class Program {
        static void Main() {
            int i = 0;
            foreach (int value in Fibonacci.InfiniteFibonacci()) {
                Console.Write(value + " ");
                if (++i == 10)
                    break;
            }
            Console.WriteLine();

            i = 0;
            foreach (int value in Fibonacci.InfiniteFibonacci()) {
                Console.Write(value + " ");
                if (++i == 10)
                    break;
            }
            Console.WriteLine();





            var chrono = new Stopwatch();
            chrono.Start();
            i = 0;
            foreach (int value in Fibonacci.LazyFibonacci(10, 15))
            {
                Console.Write(value + " ");
            }
            chrono.Stop();
            long lazy = chrono.ElapsedTicks;
            Console.WriteLine("Con evaluación perezosa: " + lazy);

            Console.WriteLine();

            var chrono2 = new Stopwatch();
            chrono2.Start();
            i = 0;
            foreach (int value in Fibonacci.EagerFibonacci(10, 15))
            {
                Console.Write(value + " ");
            }
            chrono2.Stop();
            long eager = chrono2.ElapsedTicks;
            Console.WriteLine("Con bucles: " + eager);




        }
    }
}
