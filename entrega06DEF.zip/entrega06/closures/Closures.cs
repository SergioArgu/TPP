﻿using System;

namespace TPP.Laboratory.Functional.Lab06 {

    /// <summary>
    /// Try to guess the behavior of this program without running it
    /// </summary>
    class Closures {

        /// <summary>
        /// Version with a single method
        /// </summary>
        static Func<int> Counter() {
            int counter = 0;
            return () => ++counter;
        }

        static (Func<int> inc, Func<int> dec) Counter2()
        {
            int counter = 0;
            return (() => ++counter, () => --counter);
        }

        static (Func<int> inc, Func<int> dec, Action<int> set) Counter3()
        {
            int counter = 0;
            return (() => ++counter, () => --counter, (x) => counter=x);
        }

        static void Main() {
            Func<int> counter = Counter();
            Console.WriteLine(counter());//1Devuleves counter junto a todas las variables a las que está ligao. Sería lo mismo que un objeto
            Console.WriteLine(counter());//2
            
            Func<int> anotherCounter = Counter();
            Console.WriteLine(anotherCounter());//1
            Console.WriteLine(anotherCounter());//2

            Console.WriteLine(counter());//3
            Console.WriteLine(counter());//4





            var counter2 = Counter2();
            Console.WriteLine(counter2.inc());//Para que se vea claro que es como un objeto
            Console.WriteLine(counter2.dec());


            var counter3 = Counter3();
            Console.WriteLine(counter3.inc());//Para que se vea claro que es como un objeto
            Console.WriteLine(counter3.dec());
            counter3.set(10);
            Console.WriteLine(counter3.inc());
        }
    }

}
