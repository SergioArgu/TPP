﻿
namespace Lab09
{

    internal class Worker {

        private BitcoinValueData[] vector;

        private int fromIndex, toIndex, valorPrefijado;

        private long result;

        internal long Result {
            get { return this.result; }
        }

        internal Worker(BitcoinValueData[] vector, int fromIndex, int toIndex, int valorPrefijado) {
            this.vector = vector;
            this.fromIndex = fromIndex;
            this.toIndex = toIndex;
            this.valorPrefijado = valorPrefijado;
        }

        internal void Compute() {
            this.result = 0;
            for(int i= this.fromIndex; i<=this.toIndex; i++)
                if (vector[i].Value > valorPrefijado)
                {
                    result += 1;
                }
        }

    }

}
