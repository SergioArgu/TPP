﻿using System;
using System.Formats.Tar;

namespace Lab09
{
    
    public class VectorModulusProgram {

        public static void Main(string[] args) {

            var data2 = Utils.GetBitcoinData();

            Master master = new Master(data2, 1, 7000);
            DateTime before = DateTime.Now;
            double result = master.numberOfTimesBitcoinAbove();
            DateTime after = DateTime.Now;
            Console.WriteLine("Result with one thread: {0:N2}.", result);//Secuencial
            Console.WriteLine("Elapsed time: {0:N0} ticks.",
                (after - before).Ticks );

            master = new Master(data2, 4, 7000);
            before = DateTime.Now;
            result = master.numberOfTimesBitcoinAbove();
            after = DateTime.Now;
            Console.WriteLine("Result with 4 threads: {0:N2}.", result);//Concurrente
            Console.WriteLine("Elapsed time: {0:N0} ticks.",
                (after - before).Ticks);
        }

        

    }

}
