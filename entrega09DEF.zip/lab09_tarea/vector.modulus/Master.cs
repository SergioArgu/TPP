﻿using System;
using System.Threading;

namespace Lab09
{

    public class Master {

        private BitcoinValueData[] arrayBitcoin;

        private int numberOfThreads;

        private int valorPrefijado;

        public Master(BitcoinValueData[] arrayBitcoin, int numberOfThreads, int valorPrefijado) {
            if (numberOfThreads < 1 || numberOfThreads > arrayBitcoin.Length)
                throw new ArgumentException("The number of threads must be lower or equal to the number of elements in the vector.");
            this.arrayBitcoin = arrayBitcoin;
            this.numberOfThreads = numberOfThreads;
            this.valorPrefijado = valorPrefijado;
        }

        public double numberOfTimesBitcoinAbove() {
            Worker[] workers = new Worker[this.numberOfThreads];
            int itemsPerThread = this.arrayBitcoin.Length/numberOfThreads;
            for(int i=0; i < this.numberOfThreads; i++)
                workers[i] = new Worker(this.arrayBitcoin, i*itemsPerThread, (i<this.numberOfThreads-1) ? (i+1)*itemsPerThread-1: this.arrayBitcoin.Length-1, valorPrefijado);

            Thread[] threads = new Thread[workers.Length];
            for(int i=0;i<workers.Length;i++) {
                threads[i] = new Thread(workers[i].Compute); 
                threads[i].Name = "Worker " + (i+1); 
                threads[i].Priority = ThreadPriority.BelowNormal; 
                threads[i].Start();
                
            }
            
            foreach ( var t in threads){
                t.Join();
            }

            long result = 0;
            foreach (Worker worker in workers) {
                result += worker.Result;
            }
            return result;
        }

    }

}
