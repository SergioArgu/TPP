using static System.Runtime.InteropServices.JavaScript.JSType;

namespace Lab09
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void Secuencial()
        {
            var data2 = Utils.GetBitcoinData();
            Master master = new Master(data2, 1, 7000);
            double result = master.numberOfTimesBitcoinAbove();
            Assert.AreEqual(2826, result);
        }

        [TestMethod]
        public void Concurrente()
        {
            var data2 = Utils.GetBitcoinData();
            Master master = new Master(data2, 4, 7000);
            double result = master.numberOfTimesBitcoinAbove();
            Assert.AreEqual(2826, result);
        }
    }
}