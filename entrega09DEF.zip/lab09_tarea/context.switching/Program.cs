﻿using Lab09;
using System;
using System.IO;
using System.Runtime.InteropServices;

namespace TPP.Laboratory.Concurrency.Lab09 {

    class Program {

        [DllImport("Kernel32.dll")]
        private static extern bool QueryPerformanceCounter(out long lpPerformanceCount);//En esa dll de la etiqueta se encuentra este metodo por eso el extern.
        //Es un metodo ya hecho en esa dll

        static void Main(string[] args) {
            const int maxNumberOfThreads = 50;
            var data2 = Utils.GetBitcoinData();
            ShowLine(Console.Out, "Number of threads", "Ticks", "Result");
            for (int numberOfThreads = 1; numberOfThreads <= maxNumberOfThreads; numberOfThreads++) {//Esta probando cada vez con un hilo mas para ver cuantos es mejor
                Master master = new Master(data2, numberOfThreads, 7000);
                long before = 0;
                QueryPerformanceCounter(out before);
                double result = master.numberOfTimesBitcoinAbove();
                long after = 0;
                QueryPerformanceCounter(out after);
                ShowLine(Console.Out, numberOfThreads, (after - before), result);
                GC.Collect(); // Garbage collection   Esta borrando todo para no joder los tiempos de la siguiente
                GC.WaitForFullGCComplete();//Espera a que acabe de borrar toda la basura. Es como un join
            }//Para ejecutar esto y ver tiempos buenos en release!!!!!!!!!!!!!!!!
        }

        private const string CSV_SEPARATOR = ";";

        static void ShowLine(TextWriter stream, string numberOfThreadsTitle, string ticksTitle, string resultTitle) {
            stream.WriteLine("{0}{3}{1}{3}{2}{3}", numberOfThreadsTitle, ticksTitle, resultTitle, CSV_SEPARATOR);
        }

        static void ShowLine(TextWriter stream, int numberOfThreads, long ticks, double result) {
            stream.WriteLine("{0}{3}{1:N0}{3}{2:N2}{3}", numberOfThreads, ticks, result, CSV_SEPARATOR);
        }
    }

}
