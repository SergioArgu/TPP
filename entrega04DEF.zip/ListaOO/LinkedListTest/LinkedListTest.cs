

using System.Numerics;

namespace entrega02
{
    [TestClass]
    public class LinkedListTest
    {
        
        Lista<int> listaEnteros;
        Lista<String> listaString;
        Lista<PersonTO> listaPersonas;
        Lista<Double> listaDouble;

        [TestMethod]
        public void AddTest()
        {
            
            listaEnteros = new Lista<int>();
            listaString = new Lista<String>();
            listaPersonas = new Lista<PersonTO>();
            listaDouble = new Lista<Double>();

            listaEnteros.Add(7);
            PersonTO pepe = new PersonTO
            {
                FirstName = "Pepe",
                Surname = "Gomez",
            };
            listaPersonas.Add(pepe);
            listaDouble.Add(7.2);
            listaString.Add("HOLA");
            listaString.Add("lola");
            Assert.AreEqual(true, listaDouble.Contains(7.2));
            Assert.AreEqual(true, listaPersonas.Contains(pepe));
            Assert.AreEqual(true, listaEnteros.Contains(7));
            Assert.AreEqual(true, listaString.Contains("HOLA"));
            Assert.AreEqual("HOLA-lola", listaString.ToString());
        }

        [TestMethod]
        public void RemoveTest()
        {

            listaEnteros = new Lista<int>();
            listaString = new Lista<String>();
            listaPersonas = new Lista<PersonTO>();
            listaDouble = new Lista<Double>();

            listaEnteros.Add(7);
            PersonTO pepe = new PersonTO
            {
                FirstName = "Pepe",
                Surname = "Gomez",
            };
            listaPersonas.Add(pepe);
            listaDouble.Add(7.2);
            listaString.Add("HOLA");

            listaEnteros.Remove(7);
            Assert.AreEqual(false, listaEnteros.Contains(7));
            listaPersonas.Remove(pepe);
            Assert.AreEqual("HOLA", listaString.ToString());
            listaDouble.Remove(7.2);
            listaString.Remove("HOLA");
        }

        [TestMethod]
        public void GetElement()
        {

            listaEnteros = new Lista<int>();
            listaString = new Lista<String>();
            listaPersonas = new Lista<PersonTO>();
            listaDouble = new Lista<Double>();

            listaEnteros.Add(7);
            PersonTO pepe = new PersonTO
            {
                FirstName = "Pepe",
                Surname = "Gomez",
            };
            listaPersonas.Add(pepe);
            listaDouble.Add(7.2);
            listaString.Add("HOLA");
            Assert.AreEqual(7, listaEnteros.GetElement(0));
            Assert.AreEqual(pepe, listaPersonas.GetElement(0));
            Assert.AreEqual(7.2, listaDouble.GetElement(0));
            Assert.AreEqual("HOLA", listaString.GetElement(0));

        }

        [TestMethod]
        public void Contains()
        {

            listaEnteros = new Lista<int>();
            listaString = new Lista<String>();
            listaPersonas = new Lista<PersonTO>();
            listaDouble = new Lista<Double>();

            listaEnteros.Add(7);
            PersonTO pepe = new PersonTO
            {
                FirstName = "Pepe",
                Surname = "Gomez",
            };
            listaPersonas.Add(pepe);
            listaDouble.Add(7.2);
            listaString.Add("HOLA");
            Assert.AreEqual(true, listaEnteros.Contains(7));
            Assert.AreEqual(false, listaEnteros.Contains(6));
            listaEnteros.Remove(7);
            Assert.AreEqual(false, listaEnteros.Contains(7));

            Assert.AreEqual(true, listaPersonas.Contains(pepe));
            listaPersonas.Remove(pepe);
            Assert.AreEqual(false, listaPersonas.Contains(pepe));

            Assert.AreEqual(true, listaDouble.Contains(7.2));
            listaDouble.Remove(3.1);
            Assert.AreEqual(false, listaDouble.Contains(3.1));

            Assert.AreEqual(true, listaString.Contains("HOLA"));
            listaString.Remove("HOLA");
            Assert.AreEqual(false, listaString.Contains("HOLA"));

        }

        [TestMethod]
        public void ToString()
        {

            listaEnteros = new Lista<int>();
            listaString = new Lista<String>();
            listaPersonas = new Lista<PersonTO>();
            listaDouble = new Lista<Double>();

            listaEnteros.Add(7);
            PersonTO pepe = new PersonTO
            {
                FirstName = "Pepe",
                Surname = "Gomez",
            };
            listaPersonas.Add(pepe);
            listaDouble.Add(7.2);
            listaString.Add("HOLA");
            listaString.Add("ADIOS");
            Assert.AreEqual("HOLA-ADIOS", listaString.ToString());

        }
    }
        
}