﻿using System;

namespace entrega02
{

    /// <summary>
    /// Example class that only holds data: (Data) Transfer Object or Value Object
    /// </summary>
    public class PersonTO
    {

        public required string FirstName { get; set; }

        public string Surname { get; set; }

        public string Nationality { get; set; }

        public string IDNumber { get; set; }

        public DateTime DateOfBirth { get; set; }


        /* Considering that many fields are optional (IDNumber, Nationality, 
           DateOfBirth and Gender)
         * How many constructors should be defined?   */

        public override string ToString()
        {
            return $"{FirstName} {Surname}";
        }

    }

}

