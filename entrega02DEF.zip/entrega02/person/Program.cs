﻿namespace entrega02
{
    internal class Program
    {
        static void Main(string[] args)
        {
            PersonTO pepe = new PersonTO
            {
                FirstName = "Pepe",
                Surname = "Gomez",
            };
            Console.WriteLine(pepe);
        }
    }
}
