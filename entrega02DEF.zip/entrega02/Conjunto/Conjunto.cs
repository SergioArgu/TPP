﻿using System.Linq.Expressions;
using System.Xml.Linq;

namespace entrega02
{
    internal class Conjunto
    {
        private Lista elementos;
        private int NumberOfElements { get { return elementos.NumberOfElements; }}

        public Conjunto()
        {
            elementos = new Lista();
        }

        public static Conjunto operator +(Conjunto c, Object valor)//A la izquierda lo que quieres que sea el primer operador y a la derecha lo que quieres que sea el segundo
        {
            if (!c.elementos.Contains(valor))
            {
                c.elementos.Add(valor);
            }
            return c;
        }

        public static Conjunto operator -(Conjunto c, Object valor)
        {
            if (c.elementos.Contains(valor))
            {
                c.elementos.Remove(valor);
            }
            return c;
        }

        public Object this[int indice]
        {
            get
            {
                if (indice < 0 || indice >= elementos.NumberOfElements)
                    throw new IndexOutOfRangeException("Índice fuera de rango.");
                return elementos.GetElement(indice);
            }
        }

        public static Conjunto operator |(Conjunto a, Conjunto b)
        {
            Conjunto aux = a;
            for (int i = 0; i<b.elementos.NumberOfElements; i++)
            {
                if (!aux.elementos.Contains(b.elementos.GetElement(i)))
                {
                    aux.elementos.Add(b.elementos.GetElement(i));
                }
            }
            return aux;
        }

        public static Conjunto operator &(Conjunto a, Conjunto b)
        {
            Conjunto aux = new Conjunto();
            for (int i = 0; i < b.elementos.NumberOfElements; i++)
            {
                if (a.elementos.Contains(b.elementos.GetElement(i)))
                {
                    aux.elementos.Add(b.elementos.GetElement(i));
                }
            }
            return aux;
        }

        public static Conjunto operator -(Conjunto a, Conjunto b)
        {
            Conjunto aux = a;
            for (int i = 0; i < b.elementos.NumberOfElements; i++)
            {
                if (aux.elementos.Contains(b.elementos.GetElement(i)))
                {
                    aux.elementos.Remove(b.elementos.GetElement(i));
                }
            }
            return aux;
        }

        public static bool operator ^(Conjunto c, Object valor)
        {
            if (c.elementos.Contains(valor))
            {
                return true;
            }
            return false;
        }

        public String ToString()
        {
            return elementos.ToString();
        }

        static void Main(string[] args)
        {
            Conjunto conjunto1 = new Conjunto();
            conjunto1 = conjunto1 + 1;  // Añadir el elemento 1
            conjunto1 = conjunto1 + 2;  // Añadir el elemento 2
            conjunto1 = conjunto1 + 1;  // Añadir el elemento 1
            conjunto1 = conjunto1 + 3;  // Añadir el elemento 3
            Console.WriteLine("Conjunto 1: " + conjunto1.elementos.ToString());
        }
    }
}
