﻿using System;
namespace entrega02
{
    public class Program
    {
        static void Main()
        {
            
        }

    }
}

