﻿using System;

namespace entrega02
{
    public class Lista
    {

        public int NumberOfElements { get; set; }
        private Node? primerNodo;

        public void Add(Object valor)
        {
            if (primerNodo == null)
            {
                primerNodo = new Node(valor);
            }
            else
            {
                Node nodo = new Node(valor);
                Node nodoActual = primerNodo;
                for (int i = 0; i < NumberOfElements; i++)
                {
                    if (NumberOfElements - 1 == i)
                    {
                        nodoActual.Siguiente = nodo;
                    }
                    nodoActual = nodoActual.Siguiente;
                }
            }
            NumberOfElements++;
        }

        public bool Remove(Object valor)
        {
            Node nodoActual = primerNodo;
            Node nodoAnterior = nodoActual;
            if (primerNodo.Valor.Equals(valor))
            {
                primerNodo = primerNodo.Siguiente;
                NumberOfElements--;
                return true;
            }
            for (int i = 0; i < NumberOfElements; i++)
            {
                if (nodoActual.Valor.Equals(valor))
                {
                    nodoAnterior.Siguiente = nodoActual.Siguiente;
                    NumberOfElements--;
                    return true;
                }
                nodoAnterior = nodoActual;
                nodoActual = nodoActual.Siguiente;
            }
            return false;
        }

        public Object GetElement(int number)
        {
            if (number < 0 || number >= NumberOfElements)
                throw new IndexOutOfRangeException("Índice fuera de rango");

            Node nodoActual = primerNodo;
            for (int i = 0; i < number; i++)
            {
                nodoActual = nodoActual.Siguiente;
            }
            return nodoActual.Valor;
        }

        public bool Contains(Object valor)
        {
            Node nodoActual = primerNodo;
            for (int i = 0; i < NumberOfElements; i++)
            {
                if (nodoActual.Valor.Equals(valor))
                {
                    return true;
                }
                nodoActual = nodoActual.Siguiente;
            }
            return false;
        }

        public String ToString()
        {
            Node nodo = primerNodo;
            String result = "";
            for (int i = 0; i < NumberOfElements; i++)
            {
                result += nodo.Valor;
                if (nodo.Siguiente != null)
                {
                    result += "-";
                }
                nodo = nodo.Siguiente;
            }
            return result;
        }

    }
}
