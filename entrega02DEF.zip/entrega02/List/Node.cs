﻿namespace entrega02
{
    internal class Node
    {

        public Node(Object valor)
        {
            Valor = valor;
            Siguiente = null;
        }

        public Object Valor { get; set; }

        public Node? Siguiente { get; set; }

    }
}
