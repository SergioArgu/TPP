

namespace entrega02
{
    [TestClass]
    public class LinkedListTest
    {
        
      
        Lista lista;

        [TestMethod]
        public void AddTest()
        {
            
            lista = new Lista();
            lista.Add(7);
            PersonTO pepe = new PersonTO
            {
                FirstName = "Pepe",
                Surname = "Gomez",
            };
            lista.Add(pepe);
            lista.Add(7.2);
            lista.Add("HOLA");
            Assert.AreEqual(true, lista.Contains("HOLA"));
            Assert.AreEqual("7-Pepe Gomez-7,2-HOLA", lista.ToString());

        }

        [TestMethod]
        public void RemoveTest()
        {

            lista = new Lista();

            lista.Add(7);
            PersonTO pepe = new PersonTO
            {
                FirstName = "Pepe",
                Surname = "Gomez",
            };
            lista.Add(pepe);
            lista.Add(7.2);
            lista.Add("HOLA");

            lista.Remove(7);
            Assert.AreEqual(false, lista.Contains(7));
            lista.Remove(pepe);
            Assert.AreEqual("7,2-HOLA", lista.ToString());
            lista.Remove(7.2);
            lista.Remove("HOLA");
        }

        [TestMethod]
        public void GetElement()
        {

            lista = new Lista();

            lista.Add(7);
            PersonTO pepe = new PersonTO
            {
                FirstName = "Pepe",
                Surname = "Gomez",
            };
            lista.Add(pepe);
            lista.Add(7.2);
            lista.Add("HOLA");
            Assert.AreEqual(7, lista.GetElement(0));
            Assert.AreEqual(pepe, lista.GetElement(1));
            Assert.AreEqual(7.2, lista.GetElement(2));
            Assert.AreEqual("HOLA", lista.GetElement(3));

        }

        [TestMethod]
        public void Contains()
        {

            lista = new Lista();

            lista.Add(7);
            PersonTO pepe = new PersonTO
            {
                FirstName = "Pepe",
                Surname = "Gomez",
            };
            lista.Add(pepe);
            lista.Add(7.2);
            lista.Add("HOLA");
            Assert.AreEqual(true, lista.Contains(7));
            Assert.AreEqual(false, lista.Contains(6));
            lista.Remove(7);
            Assert.AreEqual(false, lista.Contains(7));

            Assert.AreEqual(true, lista.Contains(pepe));
            lista.Remove(pepe);
            Assert.AreEqual(false, lista.Contains(pepe));

            Assert.AreEqual(true, lista.Contains(7.2));
            lista.Remove(3.1);
            Assert.AreEqual(false, lista.Contains(3.1));

            Assert.AreEqual(true, lista.Contains("HOLA"));
            lista.Remove("HOLA");
            Assert.AreEqual(false, lista.Contains("HOLA"));

        }

        [TestMethod]
        public void ToString()
        {


            lista = new Lista();

            lista.Add(7);
            PersonTO pepe = new PersonTO
            {
                FirstName = "Pepe",
                Surname = "Gomez",
            };
            lista.Add(pepe);
            lista.Add(7.2);
            lista.Add("HOLA");
            Assert.AreEqual("7-Pepe Gomez-7,2-HOLA", lista.ToString());

        }
    }
        
}