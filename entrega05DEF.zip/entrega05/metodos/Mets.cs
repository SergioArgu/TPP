﻿using System;

namespace entrega05
{

    public static class Mets
    {

        static void Main(string[] args)
        {
            Console.WriteLine("Hello, World!");

            var xs = Factory.CreatePeople();
            xs.Show();

            Console.WriteLine("");
            Console.WriteLine("");
            string name = "Pepe";
            var aux = xs.Find(p => p.FirstName == name);//Cuaidado con las condiciones que hay que ponerlas bien!!!!!
            //Console.WriteLine("Result: " + aux);


            Console.WriteLine("");
            Console.WriteLine("");
            var aux2 = xs.Filter(p => p.FirstName.StartsWith('C'));
            //Console.WriteLine("Result: " + aux2);
            foreach(var x in aux2)
            {
                Console.WriteLine("Result: " + x);
            }

            Console.WriteLine("");
            Console.WriteLine("");

            var ns = Factory.CreateAngles();
            ns.Show();

            Console.WriteLine("");
            Console.WriteLine("");

            var aux3 = ns.Reduce<Angle, double>((p, t) => p.Degrees + t);//Aqui hay que indicar los params porque son varios y no lo consigue hacer automáticamente
            Console.WriteLine(aux3);
        }


        public static T Find<T>(this IEnumerable<T> xs, Func<T,bool> f)//La condición se le pasa luego al llamarlo!!!!!!!!!!!
        {
            foreach (var x in xs)
            {
                if (f(x))
                {
                    return x;
                }
            }
            throw new Exception();
        }

        public static IEnumerable<T> Filter<T>(this IEnumerable<T> xs, Func<T, bool> f)
        {
            var ys = new List<T>();
            foreach(var x in xs)
            {
                if (f(x))
                {
                    ys.Add(x);
                }
            }
            return ys;
        }

        //En Find y Filter no te dice nada de los tipos asique usas T pero en reduce en el enunciado te dice que uses dos tipos!!!!

        public static R Reduce<D,R>(this IEnumerable<D> xs, Func<D,R,R> f)//El this sirve para poder ser llamado desde cualquier objeto de ese tipo
        {
            R result=default;
            foreach(var x in xs)
            {
                result = f(x,result);
            }
            return result;
        }

        public static void Show<T>(this IEnumerable<T> xs)
        {
            foreach (var x in xs)
            {
                Console.Write($"{x.ToString()} ");
            }
            Console.WriteLine();
        }


    }
}
