using Microsoft.VisualStudio.TestPlatform.TestHost;
using System.Runtime.Serialization;
using System;
using System.Runtime.Intrinsics.X86;
using System.Numerics;

namespace entrega05
{
    [TestClass]
    public class AlgTest
    {

        [TestMethod]
        public void FindTest()
        {
            var xs = Factory.CreatePeople();
            var angles = Factory.CreateAngles();

            var result = xs.Find(p => p.FirstName == "Pepe");
            Assert.AreEqual("Pepe", result.FirstName);

            var result2 = xs.Find(p => p.FirstName == "Juan");
            Assert.AreEqual("Juan", result2.FirstName);

            var nif = xs.Find(p => p.IDNumber.EndsWith("F"));
            Assert.AreEqual("Juan", nif.FirstName);

            var angulosRectos = angles.Find(p => p.Degrees == 90);
            Assert.AreEqual(90, angulosRectos.Degrees);

            var angulosCuadrante = angles.Find(p => p.Quadrant == 3);
            Assert.AreEqual(3, angulosCuadrante.Quadrant);
        }

        [TestMethod]
        public void FilterTest()
        {
            var xs = Factory.CreatePeople();
            var angles = Factory.CreateAngles();

            var result = xs.Filter(p => p.FirstName == "Pepe");
            foreach (var x in result)
            {
                Assert.AreEqual("Pepe", x.FirstName);
            }

            var result2 = xs.Filter(p => p.FirstName == "Juan");
            foreach (var x in result2)
            {
                Assert.AreEqual("Juan", x.FirstName);
            }

            var nif = xs.Filter(p => p.IDNumber.EndsWith("F"));
            foreach (var x in nif)
            {
                Assert.IsTrue(x.IDNumber.EndsWith("F"));
            }

            var angulosRectos = angles.Filter(p => p.Degrees == 90);
            foreach (var x in angulosRectos)
            {
                Assert.AreEqual(90, x.Degrees);
            }

            var angulosCuadrante = angles.Filter(p => p.Quadrant == 3);
            foreach (var x in angulosCuadrante)
            {
                Assert.AreEqual(3, x.Quadrant);
            }
        }

        [TestMethod]
        public void ReduceTest()
        {
            var angles = Factory.CreateAngles();

            var result = angles.Reduce<Angle,double>((p,t)=>p.Degrees + t);
            Assert.AreEqual(64980, result);

            var result2 = angles.Reduce<Angle, double>((p, t) => Math.Max(Math.Sin(p.Radians),t));
            Assert.AreEqual(1, result2);
        }
    }
}